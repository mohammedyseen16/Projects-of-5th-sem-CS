<?php 

/**
* 
* Database settings
* This file will be renamed to SettingsConfig.php in subsequent versions
* 
*/
$app = new \Slim\App([
	'settings' => [
		'displayErrorDetails' => true,
	//Database definition
	'db' => [
		'driver' => 'mysql',
		'host'=> 'localhost',
		'database' => 'rawphp',
		'username' => 'root',
		'password' => '',
		'charset' => 'utf8',
		'collation' => 'utf8_unicode_ci',
		'prefix' => '',
	],
	'cakeDB' => [
		'className' => 'Cake\Database\Connection',
		'driver' => 'Cake\Database\Driver\Mysql',
		'database' => 'rawphp',
		'username' => 'root',
		'password' => '',
		'cacheMetadata' => false // If set to `true` you need to install the optional "cakephp/cache" package.

	]
  ]
]);


